#ifndef __TIME_H
#define __TIME_H

#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>

/* Function to find current time*/
void getTime();

#endif