
#include "account.h"

int main() {
  Account a1("ABC", "123", 150.45);
  a1.dispay();
  Account a2;
  a2.dispay();
  return 0;
}