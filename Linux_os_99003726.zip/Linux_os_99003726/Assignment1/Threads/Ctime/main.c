
#include "time.h"

int main()
{
  /* Get the current time*/
  getTime();
}