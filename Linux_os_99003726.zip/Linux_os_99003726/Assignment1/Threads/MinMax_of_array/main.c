#include "MaxMin.h"

int main()
{
  /* Find Maximum number */
  printf("Maximum number : %d\n", findmax());
  /* Find Minimum NUmber */
  printf("Minmum number : %d\n", findmin());
  return 0;
}